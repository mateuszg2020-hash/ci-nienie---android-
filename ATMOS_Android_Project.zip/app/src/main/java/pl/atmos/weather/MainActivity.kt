package pl.atmos.weather

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val places = linkedMapOf("Gostynin" to Pair(52.4297, 19.4619))
    private var currentPlace = "Gostynin"
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var content: LinearLayout
    private val bg = Color.rgb(11, 17, 27)
    private val panel = Color.rgb(23, 33, 48)
    private val accent = Color.rgb(89, 190, 255)
    private val white = Color.rgb(239, 245, 252)
    private val muted = Color.rgb(155, 174, 195)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadWeather()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "ATMOS"
            textSize = 27f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val add = TextView(this).apply {
            text = "+ MIASTO"
            textSize = 13f
            setTextColor(accent)
            setPadding(12, 10, 4, 10)
            setOnClickListener { addCityDialog() }
        }
        header.addView(add)
        root.addView(header)
        status = TextView(this).apply {
            text = "WEATHER INTELLIGENCE  •  ŁADOWANIE"
            textSize = 10f
            setTextColor(muted)
            setPadding(0, 4, 0, 16)
        }
        root.addView(status)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderLoading()
    }

    private fun renderLoading() {
        content.removeAllViews()
        content.addView(label("Pobieram dane pogodowe…", 18f, white, true))
    }

    private fun loadWeather() {
        val coords = places[currentPlace] ?: return
        status.text = "WEATHER INTELLIGENCE  •  $currentPlace"
        renderLoading()
        io.execute {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=${coords.first}&longitude=${coords.second}" +
                    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m" +
                    "&hourly=temperature_2m,precipitation_probability,precipitation,relative_humidity_2m,pressure_msl,wind_speed_10m" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max" +
                    "&forecast_days=7&timezone=auto"
                val json = JSONObject(URL(url).openConnection().apply {
                    connectTimeout = 12000
                    readTimeout = 12000
                }.getInputStream().bufferedReader().use { it.readText() })
                runOnUiThread { showWeather(json) }
            } catch (e: Exception) {
                runOnUiThread {
                    content.removeAllViews()
                    content.addView(label("Nie udało się pobrać pogody.", 20f, white, true))
                    content.addView(label("Sprawdź internet i spróbuj ponownie.", 14f, muted))
                    content.addView(action("ODŚWIEŻ") { loadWeather() })
                }
            }
        }
    }

    private fun showWeather(j: JSONObject) {
        content.removeAllViews()
        val c = j.getJSONObject("current")
        val temp = c.optDouble("temperature_2m", 0.0)
        val code = c.optInt("weather_code", 0)
        content.addView(label(currentPlace.uppercase(), 13f, accent, true))
        content.addView(label(weatherName(code), 17f, muted))
        content.addView(label("${temp.toInt()}°", 76f, white, true))
        content.addView(label("Odczuwalna ${c.optDouble("apparent_temperature").toInt()}°  •  Wilgotność ${c.optInt("relative_humidity_2m")}% ", 14f, muted))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        grid.addView(metricRow("CIŚNIENIE", "${c.optDouble("pressure_msl").toInt()} hPa", "WIATR", "${c.optDouble("wind_speed_10m").toInt()} km/h"))
        grid.addView(metricRow("PORYWY", "${c.optDouble("wind_gusts_10m").toInt()} km/h", "KIERUNEK", "${c.optInt("wind_direction_10m")}°"))
        grid.addView(metricRow("ZACHMURZENIE", "${c.optInt("cloud_cover")}%", "OPAD", "${c.optDouble("precipitation")} mm"))
        grid.addView(metricRow("CIŚNIENIE PRZY GRUNCIE", "${c.optDouble("surface_pressure").toInt()} hPa", "UV", "w prognozie"))
        content.addView(card(grid))
        content.addView(section("PROGNOZA GODZINOWA"))
        val hourly = j.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temps = hourly.getJSONArray("temperature_2m")
        val rain = hourly.getJSONArray("precipitation_probability")
        for (i in 0 until minOf(12, times.length())) {
            val time = times.getString(i).substringAfter("T")
            content.addView(label("$time     ${temps.getDouble(i).toInt()}°C     Opady ${rain.optInt(i)}%", 14f, white))
        }
        content.addView(section("PROGNOZA NA 7 DNI"))
        val daily = j.getJSONObject("daily")
        val days = daily.getJSONArray("time")
        val max = daily.getJSONArray("temperature_2m_max")
        val min = daily.getJSONArray("temperature_2m_min")
        val pop = daily.getJSONArray("precipitation_probability_max")
        for (i in 0 until days.length()) {
            val date = days.getString(i)
            content.addView(label("$date      ${max.getDouble(i).toInt()}° / ${min.getDouble(i).toInt()}°      Opady ${pop.optInt(i)}%", 14f, white))
        }
        content.addView(section("LOKALIZACJE"))
        places.keys.forEach { name ->
            content.addView(action(if (name == currentPlace) "✓  $name" else name) {
                currentPlace = name
                loadWeather()
            })
        }
        content.addView(label("Dane pogodowe: Open-Meteo • ATMOS 0.1.0", 11f, muted))
    }

    private fun metricRow(a: String, av: String, b: String, bv: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(metric(a, av), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(metric(b, bv), LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun metric(title: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 8, 12)
        }
        box.addView(label(title, 10f, muted, true))
        box.addView(label(value, 19f, white, true))
        return box
    }

    private fun card(v: View): View {
        return LinearLayout(this).apply {
            setPadding(8, 8, 8, 8)
            setBackgroundColor(panel)
            addView(v)
        }.also { val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 18, 0, 10); it.layoutParams = p }
    }

    private fun section(s: String): View = label(s, 13f, accent, true).apply {
        setPadding(0, 22, 0, 8)
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, 4, 0, 4)
        }

    private fun action(s: String, click: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 15f
        setTextColor(white)
        setPadding(14, 12, 14, 12)
        setBackgroundColor(panel)
        setOnClickListener { click() }
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 4, 0, 4); layoutParams = p
    }

    private fun addCityDialog() {
        val input = EditText(this).apply { hint = "Wpisz nazwę miasta"; setSingleLine() }
        AlertDialogBuilder(this).show(input) { city ->
            if (city.isBlank()) return@show
            io.execute {
                try {
                    val q = URLEncoder.encode(city, "UTF-8")
                    val data = URL("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=pl&format=json")
                        .openStream().bufferedReader().use { it.readText() }
                    val results = JSONObject(data).optJSONArray("results")
                    if (results == null || results.length() == 0) throw Exception("Nie znaleziono miasta")
                    val place = results.getJSONObject(0)
                    val name = place.optString("name")
                    runOnUiThread {
                        places[name] = Pair(place.getDouble("latitude"), place.getDouble("longitude"))
                        currentPlace = name
                        loadWeather()
                    }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Nie znaleziono lokalizacji", Toast.LENGTH_LONG).show() }
                }
            }
        }
    }

    private fun weatherName(code: Int) = when (code) {
        0 -> "Bezchmurnie"
        1, 2 -> "Małe zachmurzenie"
        3 -> "Pochmurno"
        45, 48 -> "Mgła"
        in 51..67 -> "Mżawka lub deszcz"
        in 71..77 -> "Śnieg"
        in 80..82 -> "Przelotne opady"
        in 95..99 -> "Burza"
        else -> "Warunki pogodowe"
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}

private class AlertDialogBuilder(private val activity: Activity) {
    fun show(input: EditText, onOk: (String) -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("Dodaj lokalizację")
            .setView(input)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Szukaj") { _, _ -> onOk(input.text.toString().trim()) }
            .show()
    }
}
