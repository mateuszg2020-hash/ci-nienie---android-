# Ciśnienie – aplikacja Android

Prosta aplikacja pokazująca aktualne ciśnienie atmosferyczne w hPa na podstawie lokalizacji telefonu.

## Funkcje
- prosi o dostęp do lokalizacji telefonu;
- pobiera współrzędne GPS/sieciowe;
- pobiera `surface_pressure` z API Open-Meteo;
- pokazuje wynik w hPa i czas danych;
- przycisk ręcznego odświeżania.

## Jak uruchomić
1. Rozpakuj archiwum.
2. Otwórz folder `CisnienieAndroid` w Android Studio.
3. Poczekaj na synchronizację Gradle.
4. Podłącz telefon z włączonym debugowaniem USB albo uruchom emulator.
5. Kliknij Run.

Do zbudowania APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Ważne
- Wymaga Androida 8.0 lub nowszego.
- Wymaga internetu i zgody na lokalizację.
- Aplikacja pokazuje ciśnienie przy powierzchni terenu (`surface_pressure`), a nie ciśnienie zredukowane do poziomu morza używane często w prognozach pogody.
- Dane pochodzą z Open-Meteo: https://open-meteo.com/ (bez klucza API).

## Budowanie APK automatycznie przez GitHub
W projekcie jest workflow `.github/workflows/build-apk.yml`. Po wgraniu projektu do repozytorium GitHub:
1. Otwórz zakładkę **Actions**.
2. Wybierz **Build Android APK** i kliknij **Run workflow** (lub wypchnij commit na `main`).
3. Po zakończeniu pobierz artefakt **Cisnienie-debug-apk** – w środku będzie `app-debug.apk`.


## Automatyczne budowanie APK przez GitHub
Projekt zawiera workflow `.github/workflows/build-apk.yml`. Po dodaniu plików do gałęzi `main` GitHub Actions automatycznie zbuduje APK. Możesz też uruchomić budowanie ręcznie z zakładki Actions przez `Run workflow`.
Gotowy plik pobierzesz z zakończonego uruchomienia: sekcja **Artifacts** → **Cisnienie-APK**.
