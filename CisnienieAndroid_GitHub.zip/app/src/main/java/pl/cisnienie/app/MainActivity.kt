package pl.cisnienie.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var pressureText: TextView
    private lateinit var statusText: TextView
    private lateinit var locationText: TextView
    private lateinit var updatedText: TextView
    private lateinit var refreshButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var locationManager: LocationManager
    private var locationListener: LocationListener? = null
    private var timeout: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pressureText = findViewById(R.id.pressureText)
        statusText = findViewById(R.id.statusText)
        locationText = findViewById(R.id.locationText)
        updatedText = findViewById(R.id.updatedText)
        refreshButton = findViewById(R.id.refreshButton)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        refreshButton.setOnClickListener { loadPressure() }
        loadPressure()
    }

    private fun loadPressure() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                100
            )
            statusText.text = "Zezwól aplikacji na dostęp do lokalizacji."
            return
        }

        statusText.text = "Ustalanie lokalizacji…"
        refreshButton.isEnabled = false

        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        var best: Location? = null
        try {
            for (provider in providers) {
                val candidate = try { locationManager.getLastKnownLocation(provider) } catch (_: Exception) { null }
                if (candidate != null && (best == null || candidate.accuracy < best!!.accuracy)) best = candidate
            }
        } catch (_: Exception) {}

        if (best != null && System.currentTimeMillis() - best!!.time < 15 * 60 * 1000) {
            fetchPressure(best!!)
            return
        }

        var received = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!received) {
                    received = true
                    stopLocationUpdates()
                    fetchPressure(location)
                }
            }
            @Deprecated("Deprecated in Android")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        locationListener = listener

        try {
            var requested = false
            for (provider in providers) {
                if (provider == LocationManager.GPS_PROVIDER &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    continue
                }
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestLocationUpdates(provider, 1000L, 0f, listener, Looper.getMainLooper())
                    requested = true
                }
            }
            if (!requested) {
                stopLocationUpdates()
                showError("Włącz lokalizację GPS w telefonie.")
                return
            }
            timeout = Runnable {
                if (!received) {
                    received = true
                    stopLocationUpdates()
                    showError("Nie udało się ustalić lokalizacji. Spróbuj ponownie na zewnątrz.")
                }
            }
            handler.postDelayed(timeout!!, 20000L)
        } catch (_: SecurityException) {
            stopLocationUpdates()
            showError("Brak uprawnień do lokalizacji.")
        } catch (e: Exception) {
            stopLocationUpdates()
            showError("Nie można pobrać lokalizacji.")
        }
    }

    private fun stopLocationUpdates() {
        try { locationListener?.let { locationManager.removeUpdates(it) } } catch (_: Exception) {}
        locationListener = null
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
    }

    private fun fetchPressure(location: Location) {
        statusText.text = "Pobieranie aktualnego ciśnienia…"
        locationText.text = String.format(Locale.getDefault(), "Lokalizacja: %.4f, %.4f", location.latitude, location.longitude)
        executor.execute {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=surface_pressure&timezone=auto")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 10000
                    requestMethod = "GET"
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val current = JSONObject(body).getJSONObject("current")
                val pressure = current.getDouble("surface_pressure")
                val apiTime = current.optString("time", "")
                runOnUiThread {
                    pressureText.text = String.format(Locale.US, "%.1f", pressure)
                    statusText.text = "Aktualne ciśnienie atmosferyczne przy powierzchni"
                    updatedText.text = if (apiTime.isNotBlank()) "Dane pomiarowe: $apiTime" else "Odświeżono: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}"
                    refreshButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { showError("Nie udało się pobrać danych. Sprawdź internet i spróbuj ponownie.") }
            }
        }
    }

    private fun showError(message: String) {
        statusText.text = message
        refreshButton.isEnabled = true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) loadPressure()
            else {
                statusText.text = "Bez dostępu do lokalizacji aplikacja nie może określić ciśnienia."
                refreshButton.isEnabled = true
            }
        }
    }

    override fun onDestroy() {
        stopLocationUpdates()
        executor.shutdownNow()
        super.onDestroy()
    }
}
