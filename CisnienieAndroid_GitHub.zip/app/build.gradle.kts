plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pl.cisnienie.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "pl.cisnienie.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
